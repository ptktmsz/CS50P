mass = input("Enter mass in kg ")

lightspeed = 300000000

energy = int(mass) * int(lightspeed) ** 2

print(energy)
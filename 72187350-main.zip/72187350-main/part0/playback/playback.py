# użytkownik wpisuje tekst
tekst = input()

# zamienia spacje na trzy kropki
tekst = tekst.replace(" ","...")

# wyświetla poprawny tekst
print(tekst)
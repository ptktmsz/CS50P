# użytkownik wpisuje tekst
tekst = input()

# zamienia tekst na wielkie małe znaki
tekst = tekst.lower()

# wyświetla tekst zamieniony na małe znaki
print(tekst)
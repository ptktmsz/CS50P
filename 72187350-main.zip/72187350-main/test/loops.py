i = 0
while i < 3:
    print("meow")
    i += 1

for _ in range(3):
    print("woof")

print("moo\n" * 3, end="")
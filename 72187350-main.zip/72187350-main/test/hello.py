# Pyta o imię.
imie = input("Jak masz na imię? ")

# Wita użytkownika.
print (f"Hello, {imie}")
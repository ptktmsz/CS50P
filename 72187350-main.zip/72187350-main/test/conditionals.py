x = int(input("Podaj X: "))
y = int(input("Podaj Y: "))

if x < y:
    print("X jest mniejsze od Y")

elif x > y:
    print("X jest większe od Y")

else:
    print("X jest równe Y")
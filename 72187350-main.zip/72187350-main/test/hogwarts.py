students = ["Hermione", "Harry", "Ron"]

print(students[0])
print(students[1])
print(students[2])

for student in students:
    print(student)
def main():
    x = int(input("Podaj X: "))
    if is_even(x):
        print("Parzysta")
    else:
        print("Nieparzysta")

def is.even(n):
    return n % 2 == 0

main()
def hello(komu="world"):
    print("hello,", komu)

name = input("Jak masz na imię? ")
hello(name)
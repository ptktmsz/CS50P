x = float(input("Jaki jest X? "))
y = float(input("Jaki jest Y? "))

z = round(x + y)

print(f"{z:,}")
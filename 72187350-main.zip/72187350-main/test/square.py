def main():
    x = int(input("Jaki jest X? "))
    print("X do kwadratu to", square(x))

def square(n):
    return n * n

main()
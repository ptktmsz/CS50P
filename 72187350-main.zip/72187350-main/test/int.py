x = int(input("Jaki jest X? "))
y = int(input ("Jaki jest Y? "))

print (x + y)
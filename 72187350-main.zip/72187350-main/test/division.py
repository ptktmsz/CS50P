x = float(input("Jaki jest X? "))
y = float(input("Jaki jest Y? "))

z = x / y

print(f"{z:.2f}")